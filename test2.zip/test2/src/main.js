const hemburger = document.getElementById('hemburger');
const navMenu = document.getElementById('nav-menu');
const closeIcon = document.getElementById("nav-close");
const navLink = document.querySelectorAll(".nav__link");

navLink.forEach(link =>
        link.addEventListener("click",() => {
            navMenu.classList.add('hidden')
        })
    )

closeIcon.addEventListener("click",() => {
    navMenu.classList.add('hidden')
})

hemburger.addEventListener("click", ()=> {
    navMenu.classList.remove('hidden')
})

/* Tabs */

const tabs = document.querySelectorAll(".tabs_wrap ul li");
console.log(tabs)
tabs.forEach(tab=> {
    tab.addEventListener("click", () => {
        tabs.forEach(tab => {
            
            tab.classList.remove("active")
        })
        tab.classList.add('active')
    })
})