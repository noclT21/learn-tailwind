/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    screens : {
      sm : "480px",
      md : "760px",
      lg : "1024px",
    },
    extend: {
      colors : {
        primaryColor : '#010a5e',
        primaryColorLight : '#010d78',
        seconderyColor : '#ffcc00',
        paragraphColor : '#c0c0c0',
        whiteColor : '#fff',
        blackColor : '#000',
        greenColor : '#007936',
        redColor : '#cc3433',
        darkColor : '#000',
        darkColorLight : '#171717',
      },
      keyframes : {
        move : {
          "50%" : {Transform : 'translateY(-1rem)'}
        }
      },
      animation : {
        'movingY' : 'move 2s linear infinite'
      }
    },
    container : {
      center : true,
      padding : {
        DEFULT : '1rem',
        sm : '1.5rem',

      }
    },
    fontFamily : {
      oswald : ['Oswand', 'sens-serif'],
      dmsans : ['DM sans', 'sans-serif']
    }
  },
  plugins: [],
}